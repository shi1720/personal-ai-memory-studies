# Anonymous arithmetic reproducibility supplement

This supplement accompanies *A Controlled Audit of Personal AI Memory for
Rating Prediction*. It reproduces the aggregation and uncertainty calculations from the
released per-user error summaries. It contains 5,400 user-system summary rows
across two datasets and checks all ten primary comparisons, both operational
and paired common-valid estimates.

## Run

Use Python 3.9 through 3.12 and NumPy 1.26.4. From this directory:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python src/verify_published_results.py
.venv/bin/python -m unittest discover -s tests -v
```

On Windows use `.venv\Scripts\python` instead. Verification is CPU-only and
requires no source datasets, inference models, network service, or API key.
Installing the declared dependency requires access to a Python package source.
Do not invoke Python with `-O`: the checker deliberately uses assertions and
rejects execution with assertions disabled.

Successful verification prints a JSON report and writes
`verification-result.json`. The verifier checks the archive member hashes,
per-system means, user-macro RMSE, metric identities and ranges, validity counts,
duplicate rows, and all reported paired bootstrap intervals. There are 10,000
paired user resamples with seed 20260920; the interval endpoints are 0.025 and
0.975 for ordinary intervals and 0.0025 and 0.9975 for the adjusted intervals.
User row order is retained exactly because it determines deterministic bootstrap
resampling. The included tests ensure that damaged aggregates, duplicate rows,
corrupted intervals, changed files, and unsafe manifest paths are rejected.

## Contents and limits

The two analysis JSON files are byte-for-byte copies of the original completed
reports, not anonymized numerical reconstructions. They contain per-user error
summaries, aggregate results, contrast estimates, resource summaries, and relative
dependency names and hashes. The anonymous manifest records their original
SHA-256 values. No source ratings, prediction arrays, full prompts, generated
memory texts, model weights, Git history, or author-identifying links are included.

The source dependency entries inside each original report refer to files from
the complete research artifact which are intentionally not distributed here.
This portable verifier checks the two reports and its distributed code against
the anonymous manifest. It does not validate those absent dependencies, original
trace provenance, correctness of predictions against source targets, dataset
acquisition, or model inference. Hashes detect inconsistency within this package;
they are not an independently signed certificate of authenticity. Computational
consistency is not an external laboratory replication or peer review.

The mathematical verification functions and original two regression tests are
copied unchanged from the completed artifact. Packaging and integrity tests are
additional. Original primary analyses, hypotheses, and results are unchanged.
No third-party source code is included; NumPy is an external dependency governed
by its own license. This temporary anonymous distribution is supplied for review
and reproduction of the accompanying reported calculations.

## Optional numerical stability audit

The separate `src/review_bootstrap_stability.py` and its recorded output are
included. After verifying the package, reproduce this additional calculation:

```sh
.venv/bin/python src/review_bootstrap_stability.py
```

This recomputes 200,000 bootstrap samples for each of the ten operational
contrasts under two additional seeds. It uses the same user summaries, not new
data, and leaves the frozen primary reports untouched. It is a post-review
Monte Carlo stability audit, not an enlarged primary analysis. It overwrites
only `results/review-bootstrap-stability.json`, including current environment
metadata; when using a different Python or NumPy version, the file hash can
therefore change even if its numerical findings agree. Run package integrity
verification before this optional regeneration, or use a fresh extraction.
