"""Package integrity must fail closed on damage or unsafe paths."""
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from verify_published_results import verify_package


class PackageIntegrityChecks(unittest.TestCase):
    def make_fixture(self, root):
        names = ['confirmation-analysis.json', 'movie-validation-analysis.json']
        (root / 'results').mkdir()
        hashes = {}
        for name in names:
            (root / 'results' / name).write_bytes(b'{}\n')
            hashes[name] = hashlib.sha256(b'{}\n').hexdigest()
        manifest = {'verification_scope': 'summary arithmetic only',
                    'original_report_sha256': hashes,
                    'files': {'results/' + k: v for k, v in hashes.items()}}
        (root / 'manifest.json').write_text(json.dumps(manifest))
        return manifest

    def test_changed_member_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.make_fixture(root)
            verify_package(root)
            (root / 'results/confirmation-analysis.json').write_bytes(b'{"changed":true}\n')
            with self.assertRaises(AssertionError):
                verify_package(root)

    def test_unsafe_manifest_path_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            manifest = self.make_fixture(root)
            manifest['files']['../outside.json'] = '0' * 64
            (root / 'manifest.json').write_text(json.dumps(manifest))
            with self.assertRaises(AssertionError):
                verify_package(root)

    def test_original_report_hash_mismatch_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            manifest = self.make_fixture(root)
            manifest['original_report_sha256']['confirmation-analysis.json'] = '0' * 64
            (root / 'manifest.json').write_text(json.dumps(manifest))
            with self.assertRaises(AssertionError):
                verify_package(root)


if __name__ == '__main__':
    unittest.main()
